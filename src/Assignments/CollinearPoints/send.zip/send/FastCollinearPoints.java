import java.util.ArrayList;
import java.util.Arrays;

import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.In;

public class FastCollinearPoints {
    private final ArrayList<LineSegment> segments;

    //find begin and end of line segment
    private Point[] max_and_min(ArrayList<Point> p) {
        Point max = new Point(Integer.MIN_VALUE,Integer.MIN_VALUE);
        Point min = new Point(Integer.MAX_VALUE,Integer.MAX_VALUE);

        for(Point i : p) {
            if(max.compareTo(i) < 0) {
                max =i;
            }
            if(min.compareTo(i) > 0) {
                min =i;
            }
        }

        Point[] res = {min, max};
        return res;
    }

    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points)   {
        if(points == null) {throw new IllegalArgumentException();}

        for(int i=0; i< points.length; i++)
            if(points[i] == null) throw new IllegalArgumentException();
            
        for(int i=0; i< points.length; i++)
            for(int j=i+1; j< points.length; j++) 
                if(points[i].compareTo(points[j]) == 0) throw new IllegalArgumentException();


        segments = new ArrayList<LineSegment>();
        Point[] cp, cp1 = points.clone();
        double slope;

        /*
        
        - Think of p as the origin.
        - For each other point q, determine the slope it makes with p.
        - Sort the points according to the slopes they makes with p.
        - Check if any 3 (or more) adjacent points in the sorted order have equal slopes with respect to p. If so, these points, together with p, are collinear.
        
        */

        Arrays.sort(cp1, 0, cp1.length);
        // for(Point p : cp) System.out.print(p + "\t");

        for(int p=0; p< cp1.length; p++) {
            cp = cp1.clone();

            //merge sort
            Arrays.sort(cp, 0, cp.length, cp[p].slopeOrder());

            for(int q=0; q< cp.length;) {
                slope = cp[q].slopeTo(cp1[p]);
 
                ArrayList<Point> pts = new ArrayList<Point>(Arrays.asList(cp1[p], cp[q++]));

                // Get all points in this line.
                for(; q < cp.length && cp[q].slopeTo(cp1[p]) == slope;) {
  
                    pts.add(cp[q++]);
                }

                //At least 4 collinear points. 
                if(pts.size() >= 4) {
                    Point[] tmp = max_and_min(pts);

                    // Since merge sort is stable and the array was previously sorted by Point natural order,
                    // the points with equal 'slopeTo' coefficients should maintain their relative order( natural order ).
                    // Therefore, the current point is not maximal.
                    // Only add segment if current point is maximal.
                    // Avoid inserting subsegments.
                    if(tmp[0] == cp1[p])
                        segments.add(new LineSegment(tmp[0], tmp[1]));

                }
            }
        }
    } 
    
    // the number of line segments
    public int numberOfSegments()    {
        return segments.size();
    }

    // the line segments
    public LineSegment[] segments()   {
        return segments.toArray(new LineSegment[numberOfSegments()]);
    }

    public static void main(String[] args) {

        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }

        StdDraw.show();
    }
}